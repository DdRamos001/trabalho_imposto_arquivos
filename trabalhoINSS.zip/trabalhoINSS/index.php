<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css.css">
    <title>Document</title>
</head>
<body>

    <img id="receita" src="receita-federal-fecha-cinco-agencias-por-falta-de-verba-30082019161829624.jpeg" alt="">

<form name="dados" method = "post" >

   
     <input type='text' name="nome" id="inputi" pattern="^(?![ ])(?!.*[ ]{2})((?:e|da|do|das|dos|de|d'|D'|la|las|el|los)\s*?|(?:[A-Z][^\s]*\s*?)(?!.*[ ]$))+$" required placeholder="Nome Completo"/>
     <br>
    
        <input type='number' name="salario" id="inputi1" pattern="[0-9]{5}" required placeholder="Salário"/>
     
        <input type='submit' name="enviar" value='enviar' id='ENVIAR'/>
        

</form>

<?php


   
if(isset($_POST["enviar"])){


$nome = $_POST["nome"];
$salario = $_POST["salario"];



if( $salario < 1903){
$irpf = 0;

};

if ( $salario > 1903 && $salario < 2826 ){

   $irpf =  $salario * 0.075;



   $salarioNew = $salario - $irpf;

};
if( $salario > 2826 && $salario < 3751 ){

    $irpf =  $salario * 0.15;

  

    $salarioNew = $salario - $irpf;
};

if( $salario > 3751 && $salario < 4664 ){

    $irpf =  $salario * 0.225;
    
   

    $salarioNew = $salario - $irpf;
};
if( $salario > 4664 ){

    $irpf =  $salario * 0.275;
    
    

    $salarioNew = $salario - $irpf;
};




$salario2 = $_POST["salario"];

if ($salario2 <= 1045 ){

    $inss = $salario2 * 0.075;
    
    

    $salarioNew2 = $salario2 - $inss;
   

};

if( $salario2 > 1046 && $salario2 < 2086){

    $inss = $salario2 * 0.09;
    
    

    $salarioNew2 = $salario2 - $inss;
   

};

if( $salario2 > 2086 && $salario2 < 3134){

    $inss = $salario2 * 0.12;
    
   

   $salarioNew2 = $salario2 - $inss;
   

};
if( $salario2 > 3135){

    $inss = $salario2 * 0.14;
    
   

    $salarioNew2 = $salario2 - $inss;

    
};

 $salarioLiquido = $salario - ($irpf + $inss);

$output_string =$nome."|".$salario."|".$irpf."|".$inss."|".$salarioLiquido."\n";

if($arquivo = fopen('dados.txt', 'a')){

    if(fwrite($arquivo, $output_string)){
        echo "<p> Registrado com sucesso </p>";
    }
    else{
        echo "Falha no registro";
    }
}
 fclose($arquivo);
 


}

 if($arquivo=fopen("dados.txt", 'r')){

    while($linha = fgets($arquivo)){

        $linha=explode("|", $linha);
        $dados['nome']=$linha[0];
        $dados['salario']=$linha[1];
        $dados['irpf']=$linha[2];
        $dados['inss']=$linha[3];
        $dados['salarioLiquido']=$linha[4];
        $dado[] = $dados;
    }

    
fclose($arquivo);
 }




?>
    <div id="SaidaDeD">
			<table class="table">
				<thead>
					<tr>
						<th>Nome</th><th>Salário bruto</th><th>IRPF</th><th>INSS</th><th>Salário Líquido</th>
					</tr>
				</thead>
				<tbody>
					<?php

                            if(isset($dado))
                            foreach($dado AS $dados){
                    
                            echo "<tr>
                            <td>".$dados['nome']."</td>
                            <td>".$dados['salario']."</td>
                            <td>".$dados['irpf']."</td>
                            <td>".$dados['inss']."</td>
                            <td>".$dados['salarioLiquido']."</td>
                            </tr>";
}
                            

                         
                      
					?>


				</tbody>
              
                     

	


     

</body>
</html>